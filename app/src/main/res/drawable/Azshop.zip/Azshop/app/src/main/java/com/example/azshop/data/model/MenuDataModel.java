package com.example.azshop.data.model;

public class MenuDataModel {
    public String name;
    public int res;

    public MenuDataModel(String name, int res) {
        this.name = name;
        this.res = res;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRes() {
        return res;
    }

    public void setRes(int res) {
        this.res = res;
    }
}
